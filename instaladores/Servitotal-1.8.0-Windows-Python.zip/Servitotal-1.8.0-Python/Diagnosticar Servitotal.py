"""Muestra los errores de inicio de Servitotal en la consola de Python."""
from pathlib import Path
import runpy
import traceback

codigo = 1
try:
    lanzador = runpy.run_path(str(Path(__file__).with_name("Abrir Servitotal.pyw")))
    codigo = lanzador["main"]()
except BaseException:
    traceback.print_exc()
try:
    input("\nPresione Enter para cerrar esta comprobación...")
except EOFError:
    pass
raise SystemExit(codigo)
