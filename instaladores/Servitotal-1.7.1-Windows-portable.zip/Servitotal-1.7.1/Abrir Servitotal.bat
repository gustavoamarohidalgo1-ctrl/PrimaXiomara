@echo off
setlocal
cd /d "%~dp0" || goto fallar
if not defined LOCALAPPDATA goto fallar
if not exist "%~dp0runtime\pythonw.exe" goto fallar
if not exist "%~dp0app\abrir_portable.pyw" goto fallar
start "" "%~dp0runtime\pythonw.exe" -I "%~dp0app\abrir_portable.pyw" --datos "%LOCALAPPDATA%\Servitotal"
if errorlevel 1 goto fallar
exit /b 0
:fallar
echo No se pudo iniciar Servitotal.
echo Extraiga TODO el ZIP y abra este archivo desde la carpeta extraida.
echo Si sigue fallando, abra Diagnosticar Servitotal.bat.
pause
exit /b 1
