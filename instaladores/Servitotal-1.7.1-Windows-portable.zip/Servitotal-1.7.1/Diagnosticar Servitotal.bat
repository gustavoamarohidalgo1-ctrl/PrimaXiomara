@echo off
setlocal
cd /d "%~dp0" || goto fallar
if not defined LOCALAPPDATA goto fallar
if not exist "%~dp0runtime\python.exe" goto fallar
echo Servitotal: comprobacion del inicio.
echo Esta ventana mostrara los errores si el programa no puede abrirse.
echo Si se abre Servitotal, cierre el programa para terminar esta comprobacion.
"%~dp0runtime\python.exe" -I "%~dp0app\abrir_portable.pyw" --datos "%LOCALAPPDATA%\Servitotal"
set "RESULTADO=%ERRORLEVEL%"
echo.
echo Codigo de salida: %RESULTADO%
pause
exit /b %RESULTADO%
:fallar
echo Falta el Python incluido o la carpeta de datos del usuario.
echo Extraiga TODO el ZIP antes de abrir Servitotal.
pause
exit /b 1
